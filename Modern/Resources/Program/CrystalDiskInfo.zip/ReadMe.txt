/*---------------------------------------------------------------------------*/
//      Product : CrystalDiskInfo
//       Author : hiyohiyo
//         Mail : hiyohiyo@crystalmark.info
//          Web : https://crystalmark.info/
//      License : MIT License
/*---------------------------------------------------------------------------*/

== Standard Edition ==
DiskInfo32.exe   : 32bit (x86)
DiskInfo64.exe   : 64bit (x64)
DiskInfoA64.exe  : 64bit (ARM64)

== Aoi Edition ==
DiskInfo32A.exe  : 32bit (x86)
DiskInfo64A.exe  : 64bit (x64)
DiskInfoA64A.exe : 64bit (ARM64)

== Shizuku Edition ==
DiskInfo32S.exe  : 32bit (x86)
DiskInfo64S.exe  : 64bit (x64)
DiskInfoA64S.exe : 64bit (ARM64)

== Kurei Kei Edition ==
DiskInfo32K.exe  : 32bit (x86)
DiskInfo64K.exe  : 64bit (x64)
DiskInfoA64K.exe : 64bit (ARM64)

== OS ==
OK: Windows XP/Vista/7/8/8.1/10/11
    Windows Server 2003/2008/2012/2016/2019/2022
NG: Windows 95/98/Me/NT4/2000
